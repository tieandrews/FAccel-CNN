#include <stdlib.h>
#include <stdio.h>

void main(void) {
    printf("hello world\n");
}
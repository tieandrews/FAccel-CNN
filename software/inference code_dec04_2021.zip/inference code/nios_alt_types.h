// create some NIOS alt_ types

#ifndef NIOS_ALT_TYPES_H
    #define NIOS_ALT_TYPES_H

    typedef char alt_8;
    typedef unsigned char alt_u8;
    typedef unsigned short alt_u16;
    typedef short alt_16;
    typedef unsigned long alt_u32;
    typedef signed long alt_32;

#endif
// try and keep this as NIOSII compatible as possible

#include <stdlib.h>
#include <stdio.h>

// rename all types to alt_ types
typedef char alt_8;
typedef unsigned char alt_u8;
typedef unsigned short alt_u16;
typedef unsigned long alt_u32;
typedef signed long alt_32;

//////////////////////////////////////////////////////////////////////////////
union IntFloat {  alt_u32 i;  float f;  };
typedef alt_u16 bfloat16;

float bf2f(bfloat16 x) { // bfloat to float
     union IntFloat f;
     f.i = ((alt_u32)x << 16);
     return f.f;
}
bfloat16 f2bf(float x) { // float to bfloat
     union IntFloat f;
     f.f = x;
     return (bfloat16)(f.i >> 16);
}

//////////////////////////////////////////////////////////////////////////////
// read BMP word 
alt_u32 read_bmp_word(alt_u8* src, alt_u8 lngth) {
    alt_u32 i, sum, d;
    sum = 0;
    for (i=0; i<lngth; i++) {
        sum += (alt_u32)src[i] << d;
        d += 8;
    }
    return sum;
}

//////////////////////////////////////////////////////////////////////////////
alt_u32 get_bmp_width(alt_u8* src) {
    return read_bmp_word(src + 18, 4);
}

//////////////////////////////////////////////////////////////////////////////
alt_u32 get_bmp_height(alt_u8* src) {
    return read_bmp_word(src + 22, 4);
}

//////////////////////////////////////////////////////////////////////////////
alt_u32 get_bmp_image_offset(alt_u8* src) {
    return read_bmp_word(src + 10, 4);
}

//////////////////////////////////////////////////////////////////////////////
alt_u32 get_bmp_bpp(alt_u8* src) {
    return read_bmp_word(src + 28, 2);
}

//////////////////////////////////////////////////////////////////////////////
bfloat16 bf_mult(bfloat16 a, bfloat16 b) {
     return f2bf(bf2f(a) * bf2f(b));
}

//////////////////////////////////////////////////////////////////////////////
bfloat16 bf_add(bfloat16 a, bfloat16 b) {
     return f2bf(bf2f(a) + bf2f(b));
}

//////////////////////////////////////////////////////////////////////////////
bfloat16* bmp_to_bfloat16_featuremap(alt_u8* src) {
    
}

//////////////////////////////////////////////////////////////////////////////
alt_u32 get_bmp_pixel(alt_u8* src, alt_u16 x, alt_u16 y) {
	alt_u32 pixel, pixel_data_offset, image_bytes, delta;
    alt_u32 image_width, image_height;
    
    pixel_data_offset = get_bmp_image_offset(src);
    image_width = get_bmp_width(src);
    image_height = get_bmp_height(src);
    image_bytes = image_width * 3;
    delta = image_bytes & 0x3;  // align image on 4 byte boundary
    if (delta > 0)
        image_bytes = image_bytes + 4 - delta;
	pixel_data_offset = pixel_data_offset + ((image_height - y - 1) * image_bytes) + (x * 3);
	pixel = src[pixel_data_offset++];
	pixel = pixel | (src[pixel_data_offset++] << 8);
	return pixel | (src[pixel_data_offset] << 16);
}

//////////////////////////////////////////////////////////////////////////////
void scale_bmp_to_featuremap(alt_u8* src, bfloat16* dst, alt_u16 sx, alt_u16 sy) {
    alt_u16 cx, cy, cz, x, y;
    float scale_width, scale_height;
    alt_u32 pixel, offset, image_width, image_height;

    image_width = get_bmp_width(src);
    image_height = get_bmp_height(src);
    scale_width =  (float)sx / (float)image_width;
    scale_height = (float)sx / (float)image_height;

    for (cy = 0; cy < sy; cy++) {
        for (cx = 0; cx < sx; cx++) {
            x = (alt_u16)((float)cx / scale_width);
            y = (alt_u16)((float)cy / scale_height);
            pixel = get_bmp_pixel(src, x, y);
            offset = 0;
            for (cz=0; cz<3; cz++) {
                dst[offset + (sx * cy) + cx] = f2bf((float)((pixel >> (cz << 3)) & 0xff) / 255.0);
                offset += sx * sy;
            }
        }
    }
}

//////////////////////////////////////////////////////////////////////////////
void main() {
    alt_u16 bmp_image_height, bmp_image_width;
    alt_u16 x, y;
    bfloat16 input_featuremap[3][64*64];
    
    FILE *f_ptr;
    alt_u32 fsize;
    
    // open the file and read to memory - this is not available in NIOS
    f_ptr = fopen("flower.bmp", "rb");
    fseek(f_ptr, 0, SEEK_END);
    fsize = ftell(f_ptr);
    fseek(f_ptr, 0, SEEK_SET);  /* same as rewind(f_ptr); */
    alt_u8* bmp_image = malloc(fsize);
    fread(bmp_image, 1, fsize, f_ptr);
    fclose(f_ptr);

    bmp_image_height = get_bmp_height(bmp_image);
    bmp_image_width = get_bmp_width(bmp_image);
    
    printf("BMP Image Details:\n");
    printf("Resolution = (%d,%d)\n", bmp_image_width, bmp_image_height);
    
    scale_bmp_to_featuremap(bmp_image, input_featuremap[0], 64, 64);
    
    for (y=0; y<8; y++) {
        for (x=0; x<8; x++) 
            printf("%f ", bf2f(input_featuremap[2][x+(y*64)]));
        printf("\n");
    }

    for (y=0; y<12; y++) {
        for (x=0; x<32; x++) 
            printf("%d ", (get_bmp_pixel(bmp_image, x, y) & 0xff0000) >> 16);
        printf("\n");
    }


    // free malloc'd memory
    free(bmp_image);   
    
}
